"""
Extensions related to built-in Turtle library.

Mock Module for Sandbox.
"""
