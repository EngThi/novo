from pedal.resolvers.core import make_resolver
from pedal.core.report import MAIN_REPORT
from pedal.core.feedback import Feedback


@make_resolver
def resolve(report=MAIN_REPORT):
    """

    Args:
        report:

    Returns:

    """
    return ""
