"""
The collection of classes and functions used to store the fundamental Report
and Feedback objects.
"""
