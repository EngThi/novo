"""
This submodule handles all the tooling related to running Pedal from the
command line.
"""