"""
Any constants for the Assertions tool.
"""

TOOL_NAME = "assertions"
