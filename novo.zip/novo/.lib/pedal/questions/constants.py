"""
Constants for the Question tool.
"""

TOOL_NAME = "questions"
