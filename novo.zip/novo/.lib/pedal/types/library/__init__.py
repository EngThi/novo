import pedal.types.library.matplotlib
import pedal.types.library.cs1_curriculum
import pedal.types.library.designer
import pedal.types.library.drafter
import pedal.types.library.turtles
import pedal.types.library.microbit
